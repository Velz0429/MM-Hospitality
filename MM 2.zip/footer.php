<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
    <!--FONT AWESOME-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!--GOOGLE FONTS-->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Play&display=swap" rel="stylesheet"> 

<link rel="stylesheet" type="text/css" href="../css/footer.css">
</head>
<body>
<footer>
<div class="footer">
<!-- <div class="row">
<a href="#"><i class="fa fa-facebook"></i></a>
<a href="#"><i class="fa fa-instagram"></i></a>
<a href="#"><i class="fa fa-youtube"></i></a>
<a href="#"><i class="fa fa-twitter"></i></a>
</div> -->

<div class="row">
<ul>
<li><a href="contactUs.php">Contact us</a></li>
<li><a href="services.php">Our Services</a></li>
<li><a href="aboutUs.php">About Us</a></li>

</ul>
</div>

<div class="row">
Copyright © 2024 - All rights reserved 
</div>
</div>
</footer>
</body>
</html>