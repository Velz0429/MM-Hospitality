<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
   <meta charset="UTF-8">
   <title>MM HOSPITALITY</title>

    <link rel="stylesheet" type="text/css" href="../css/header.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <nav>

    <div class="navbar">
      <a href="ownerPage.php">
    <img src="imgs/logo.jpeg" alt="MM Hospitality Logo" class="logo">
</a>
      <ul class="menu">
      <li><a href="ownerPage.php" class="<?= basename($_SERVER['PHP_SELF']) == 'ownerPage.php' ? 'active' : '' ?>">Home</a></li>
        <li><a href="services.php" class="<?= basename($_SERVER['PHP_SELF']) == 'services.php' ? 'active' : '' ?>">Services</a></li>
        <li><a href="locations.php" class="<?= basename($_SERVER['PHP_SELF']) == 'locations.php' ? 'active' : '' ?>">Locations</a></li>
        <li><a href="aboutUs.php" class="<?= basename($_SERVER['PHP_SELF']) == 'aboutUs.php' ? 'active' : '' ?>">About Us</a></li>
        <li><a href="contactUs.php" class="<?= basename($_SERVER['PHP_SELF']) == 'contactUs.php' ? 'active' : '' ?>">Contact Us</a></li>
      </ul>
    </div>
  </nav>


</body>
</html>