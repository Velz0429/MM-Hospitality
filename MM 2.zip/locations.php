<!-- <?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locations</title>
    <link rel="stylesheet" type="text/css" href="../css/locations.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

</head>
<body>
<div class="top">
    
<div class="eight">
  <h1>CAPE TOWN</h1>
</div>

  <div class="responsive-container-block bigContainer">
    <div class="responsive-container-block Container">
      <div class="responsive-cell-block wk-desk-6 wk-ipadp-6 wk-tab-12 wk-mobile-12">
        <img class="bigImg" src="imgs/property1.jpg">
      </div>
      <div class="responsive-container-block sideImgContainer">
        <div class="responsive-cell-block wk-desk-12 wk-ipadp-12 wk-tab-12 wk-mobile-12 side">
          <img class="sideImg" src="imgs/property2.jpg">
        </div>
        <div class="responsive-cell-block wk-desk-12 wk-ipadp-12 wk-tab-12 wk-mobile-12 side">
          <img class="sideImg" src="imgs/property3.jpg">
        </div>
      </div>
    </div>
  </div>
</div>
<br>
<br>
<div class="top">
    
<div class="eight">
  <h1>JOHANNESBURG</h1>
</div>

  <div class="responsive-container-block bigContainer">
    <div class="responsive-container-block Container">
      <div class="responsive-cell-block wk-desk-6 wk-ipadp-6 wk-tab-12 wk-mobile-12">
        <img class="bigImg" src="imgs/property4.jpg">
      </div>
      <div class="responsive-container-block sideImgContainer">
        <div class="responsive-cell-block wk-desk-12 wk-ipadp-12 wk-tab-12 wk-mobile-12 side">
          <img class="sideImg" src="imgs/property5.jpg">
        </div>
        <div class="responsive-cell-block wk-desk-12 wk-ipadp-12 wk-tab-12 wk-mobile-12 side">
          <img class="sideImg" src="imgs/property1.jpg">
        </div>
      </div>
    </div>
  </div>
</div>
<br>
<br>


<div class="top">
    
<div class="eight">
  <h1>DURBAN</h1>
</div>

  <div class="responsive-container-block bigContainer">
    <div class="responsive-container-block Container">
      <div class="responsive-cell-block wk-desk-6 wk-ipadp-6 wk-tab-12 wk-mobile-12">
        <img class="bigImg" src="imgs/property2.jpg">
      </div>
      <div class="responsive-container-block sideImgContainer">
        <div class="responsive-cell-block wk-desk-12 wk-ipadp-12 wk-tab-12 wk-mobile-12 side">
          <img class="sideImg" src="imgs/property3.jpg">
        </div>
        <div class="responsive-cell-block wk-desk-12 wk-ipadp-12 wk-tab-12 wk-mobile-12 side">
          <img class="sideImg" src="imgs/property4.jpg">
        </div>
      </div>
    </div>
  </div>
</div>
<br>
<br>


<div class="top">
    
<div class="eight">
  <h1>PRETORIA</h1>
</div>

  <div class="responsive-container-block bigContainer">
    <div class="responsive-container-block Container">
      <div class="responsive-cell-block wk-desk-6 wk-ipadp-6 wk-tab-12 wk-mobile-12">
        <img class="bigImg" src="imgs/property5.jpg">
      </div>
      <div class="responsive-container-block sideImgContainer">
        <div class="responsive-cell-block wk-desk-12 wk-ipadp-12 wk-tab-12 wk-mobile-12 side">
          <img class="sideImg" src="imgs/property1.jpg">
        </div>
        <div class="responsive-cell-block wk-desk-12 wk-ipadp-12 wk-tab-12 wk-mobile-12 side">
          <img class="sideImg" src="imgs/property2.jpg">
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>

-->





 
<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locations</title>
    <link rel="stylesheet" type="text/css" href="../css/locations.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
</head>
<body>
<div class="top">
    <div class="eight">
        <h1>CAPE TOWN</h1>
    </div>
    <div class="imgGallery">
    <section>
	<img src="imgs/CapeTown.jpg" alt="">
	<article>
		<div></div>
		<div></div>
		<div></div>
		<div></div>
		<div></div>
	</article>
</section>
</div>
</div>

<div class="top">
    <div class="eight">
        <h1>JOHANNESBURG</h1>
    </div>
    <div class="imgGallery">
    <section>
	<img src="imgs/Joburg2.jpg" alt="">
	<article>
		<div></div>
		<div></div>
		<div></div>
		<div></div>
		<div></div>
	</article>
</section>
</div>
</div>

<div class="top">
    <div class="eight">
        <h1>DURBAN</h1>
    </div>
    <div class="imgGallery">
    <section>
	<img src="imgs/Durban.jpg" alt="">
	<article>
		<div></div>
		<div></div>
		<div></div>
		<div></div>
		<div></div>
	</article>
</section>
</div>
</div>

<div class="top">
    <div class="eight">
        <h1>PRETORIA</h1>
    </div>
    <div class="imgGallery">
    <section>
	<img src="imgs/Pretoria.jpg" alt="">
	<article>
		<div></div>
		<div></div>
		<div></div>
		<div></div>
		<div></div>
	</article>
</section>
</div>
</div>



</body>
</html>

<?php include 'footer.php'; ?>
