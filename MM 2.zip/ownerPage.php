
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MM HOSPITALITY</title>
    <link rel="stylesheet" type="text/css" href="../css/ownerPage.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    
    
</head>
<body>
<?php include 'header.php'; ?>
<div class="title">
        <div class="content">
            <h1>Airbnb property management</h1>
            <h3>Make money by letting your property out to guests</h3>
            <!-- <div class="valuationButton">
                <a href="#">
                    <button type="button">Free Valuation</button>
                </a>
            </div> -->
        </div>
        <div class="ownerImage">
            <img src="imgs/lvHomepage.jpg" alt="Image of property">
        </div>
    </div>

    <br>
    <br>
    <div class="carousel-container">
        <div class="carouselTitle">
            <h1>Why choose us?</h1>
        </div>
  <ul class="tilesWrap">
    <li>
      <h2>01</h2>
      <h3>Maximize Rental Income</h3>
      <p>
      Optimize your earnings without the daily operational headaches.
      </p>
    </li>

    <li>
      <h2>02</h2>
      <h3>Superior Guest Experience</h3>
      <p>
      Delight guests with seamless bookings and impeccable service.
      </p>
    </li>

    <li>
      <h2>03</h2>
      <h3>Effortless Management</h3>
      <p>
      From cleaning to maintenance, we handle it all so you don't have to.
      </p>
    </li>

    <li>
      <h2>04</h2>
      <h3>Expert Marketing</h3>
      <p>
      Reach more guests and increase occupancy with strategic listing management.
      </p>
    </li>

    <li>
      <h2>05</h2>
      <h3>24/7 Support</h3>
      <p>
      Our team is always available to manage inquiries and support your guests.
      </p>
    </li>

    <li>
      <h2>06</h2>
      <h3>Local Expertise</h3>
      <p>
      Benefit from our knowledge of the local market and industry connections.

      </p>
    </li>

    <!-- <li>
      <h2>07</h2>
      <h3>Professionalism Guaranteed</h3>
      <p>
    Trust in our commitment to professionalism and service excellence.
      </p>
    </li> -->

  </ul>
</div>

<div class="container">
        <h1>Services Offered</h1>
        <p class="description">
        We offer superior quality and seamless co-hosting services.
Optimizing rental income for property owners while
elevating the guest experience.
        </p>
        <br>
        <div>
            <ul class="nav-bar">
                <li class="nav-item active" data-tab="listing-management">Listing Management</li>
                <li class="nav-item" data-tab="guest-management">Guest Management</li>
                <li class="nav-item" data-tab="property-management">Property Management</li>
            </ul>
</div>
        <br>
        <div id="listing-management" class="tab active">
            <p><strong>Listing Optimization:</strong> We create and regularly update your listings for maximum exposure.</p>
            <br>
            <p><strong>Pricing Strategy:</strong> We implement dynamic pricing adjustments to maximize occupancy and revenue.</p>
            <br>
            <p><strong>Marketing:</strong> We promote your property on social media and other platforms to attract more guests.</p>
            <br>
        </div>
        
        <div id="guest-management" class="tab">
            <p><strong>Guest Communication:</strong> We offer 24/7 availability to handle inquiries, bookings, and guest support.</p>
            <br>
            <p><strong>Check-In/Check-Out:</strong> We manage key exchanges and inspection services to ensure a seamless experience for guests.</p>
            <br>
            <p><strong>Enhanced Guest Experience:</strong> We strive to elevate the guest experience, encouraging positive reviews and repeat bookings.</p>
            <br>
        </div>
        
        <div id="property-management" class="tab">
            <p><strong>Coordination of Cleaning and Maintenance:</strong> We schedule and oversee cleaning and maintenance to ensure your property is always in top condition.</p>
            <br>
            <p><strong>Restocking Supplies:</strong> We handle the restocking of necessary supplies, so your guests have everything they need during their stay.</p>
            <br>
            <p><strong>Reliable Local Service Providers:</strong> We establish relationships with dependable local cleaners and maintenance personnel to maintain high standards.</p>
            <br>
        </div>
    </div>
    

    <div class="examplesContainer">
        <h1>Examples of Properties We Work With</h1>
        <div class="examples-carousel">
            <div class="carousel">
                <div class="carousel-item"><img src="imgs/property1.jpg" alt="Property 1"></div>
                <div class="carousel-item"><img src="imgs/property2.jpg" alt="Property 2"></div>
                <div class="carousel-item"><img src="imgs/property3.jpg" alt="Property 3"></div>
                <div class="carousel-item"><img src="imgs/property4.jpg" alt="Property 4"></div>
                <div class="carousel-item"><img src="imgs/property5.jpg" alt="Property 5"></div>
            </div>
            <button class="carousel-button prev">&lt;</button>
            <button class="carousel-button next">&gt;</button>
        </div>
    </div>


<!-- 
    <div class="testimonialsContainer">
    <h1>Client Testimonials</h1>
    <div class="testimonial-carousel-container">
        <div class="testimonial-carousel">
            <div class="testimonial-carousel-item">
                <p>"MM Hospitality has been a game-changer for my rental property. Their service is exceptional!"</p>
                <h4>- John Doe</h4>
            </div>
            <div class="testimonial-carousel-item">
                <p>"The team at MM Hospitality is professional and reliable. My rental income has increased significantly."</p>
                <h4>- Jane Smith</h4>
            </div>
            <div class="testimonial-carousel-item">
                <p>"I no longer have to worry about guest communication and property management. Highly recommended!"</p>
                <h4>- Mike Johnson</h4>
            </div>
        </div>
        <button class="carousel-button prev">&lt;</button>
        <button class="carousel-button next">&gt;</button>
    </div>
</div> -->














<script src="js/ownerPage.js"></script>

</body>
</html>

<?php include 'footer.php'; ?>