<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services</title>
    <link rel="stylesheet" type="text/css" href="../css/services.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Merriweather:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

</head>
<body>
    

<div class="container">
        <h1>Services Offered</h1>
        <p class="description">
        We offer superior quality and seamless co-hosting services.
Optimizing rental income for property owners while
elevating the guest experience.
        </p>
        <br>
        <div>
            <ul class="nav-bar">
                <li class="nav-item active" data-tab="listing-management">Listing Management</li>
                <li class="nav-item" data-tab="guest-management">Guest Management</li>
                <li class="nav-item" data-tab="property-management">Property Management</li>
            </ul>
</div>
        <br>
        <div id="listing-management" class="tab active">
            <p><strong>Listing Optimization:</strong> We create and regularly update your listings for maximum exposure.</p>
            <br>
            <p><strong>Pricing Strategy:</strong> We implement dynamic pricing adjustments to maximize occupancy and revenue.</p>
            <br>
            <p><strong>Marketing:</strong> We promote your property on social media and other platforms to attract more guests.</p>
            <br>
        </div>
        
        <div id="guest-management" class="tab">
            <p><strong>Guest Communication:</strong> We offer 24/7 availability to handle inquiries, bookings, and guest support.</p>
            <br>
            <p><strong>Check-In/Check-Out:</strong> We manage key exchanges and inspection services to ensure a seamless experience for guests.</p>
            <br>
            <p><strong>Enhanced Guest Experience:</strong> We strive to elevate the guest experience, encouraging positive reviews and repeat bookings.</p>
            <br>
        </div>
        
        <div id="property-management" class="tab">
            <p><strong>Coordination of Cleaning and Maintenance:</strong> We schedule and oversee cleaning and maintenance to ensure your property is always in top condition.</p>
            <br>
            <p><strong>Restocking Supplies:</strong> We handle the restocking of necessary supplies, so your guests have everything they need during their stay.</p>
            <br>
            <p><strong>Reliable Local Service Providers:</strong> We establish relationships with dependable local cleaners and maintenance personnel to maintain high standards.</p>
            <br>
        </div>
    </div>

    <div class="joinList">
    <h1>6 easy steps to start getting income from your property </h1>
    <ol style="--length: 5" role="list">
	<li style="--i: 1">
		<h3> Initial Consultation</h3>
        <p><strong>Schedule a Meeting:</strong> Contact us to schedule an initial consultation, via phone, or through a 
video call.</p>
<p><strong>Property Tour:</strong> If feasible, images and a few insights into your property, to understand its 
features and any specific requirements.</p>
   
		
	</li>
	<li style="--i: 2">
		<h3> Define Your Needs and Goals</h3>
		<p><strong>Discuss Expectations: </strong>Clearly outline your expectations, goals, and any specific 
requirements you have for the co-hosting service.</p>
<p><strong>Service Agreement:</strong> Review and agree on the scope of services to be provided, including 
guest communication, property management, pricing strategy, and review management.
</p>
	</li>
	<li style="--i: 3">
		<h3> Formalize the Partnership</h3>
		<p><strong>Sign the Contract:</strong> Review and sign a co-hosting agreement that details the terms, 
responsibilities, and fee structure.</p>
<p><strong>Provide Access: </strong>Share necessary access to your Airbnb account, property keys, and any 
relevant documentation (e.g., house rules, emergency contacts).
</p>
	</li>
	<li style="--i: 4">
		<h3>Set Up and Optimize</h3>
		<p><strong>Property Preparation:</strong>Ensure the property is guest-ready, addressing any maintenance, 
        cleaning, or stocking needs.</p>
        <p><strong>Listing Optimization:</strong>Allow us to update and optimize your Airbnb listing with accurate 
        descriptions, high-quality photos, and competitive pricing.</p>
	</li>
	<li style="--i: 5">
		<h3>Launch and Manage</h3>
		<p><strong>Go Live:</strong> Once the listing is optimized, we will activate it and start managing guest inquiries and bookings.</p>
        <p><strong>Ongoing Management:</strong> We will handle all aspects of guest communication, cleaning 
        coordination, maintenance, and review management.</p>
	</li>
    <li style="--i: 6">
		<h3>Regular Reporting and Feedback</h3>
		<p><strong>Monthly Reports</strong> Receive regular reports on occupancy rates, revenue, guest feedback, and 
        any maintenance issues.</p>
        <p><strong>Feedback Sessions:</strong>Schedule periodic feedback sessions to discuss performance and any 
        adjustments needed to enhance service quality.</p>
     
	</li>
</ol>
            <div class="valuationButton">
                <!-- <a href="#">
                    <button type="button">See pricing</button>
                </a> -->
                <a href="locations.php">
                    <button type="button">See locations</button>
                </a>
                <a href="contactUs.php">
                    <button type="button">Contact Us</button>
                </a>
            </div>
</div>

<!-- <div class="testimonialsContainer">
    <h2>Client Testimonials</h2>
    
    <div class="testimonial">
        <p class="quote">"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla convallis libero ac urna malesuada, id faucibus metus tincidunt."</p>
        <p class="client">- John Doe</p>
    </div>
    
    <div class="testimonial">
        <p class="quote">"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium."</p>
        <p class="client">- Jane Smith</p>
    </div>
    
    <div class="testimonial">
        <p class="quote">"Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem."</p>
        <p class="client">- Michael Brown</p>
    </div>
    
</div> -->


    <script src="js/services.js"></script>
</body>
</html>













<?php include 'footer.php'; ?>